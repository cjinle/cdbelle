<?php
/**
 * ConfigAction.class.php 
 * 会员返点管理
 * @author Lok Mon Nov 12 00:31:54 CST 2012
 */